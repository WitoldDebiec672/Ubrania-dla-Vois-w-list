# A new neural network architecture (CPGNN) tailored to learn CPG representations.

### Build the Cython
```bash
python3 setup.py build_ext --inplace
```