bool isfactor(int a, int b) {
	bool res = false;
	if (a % b == 0) {
		res = true;
	}
	return res;
}
