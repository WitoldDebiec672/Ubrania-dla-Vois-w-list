public class isfactor {
    public boolean isfactor(int a, int b) {
        boolean res = false;
        if (a % b == 0) {
            res = true;
        }
        return res;
    }
}
