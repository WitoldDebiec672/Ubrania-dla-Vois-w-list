# Status
We apply for the functional and available badges in this artifact evaluation. 
To receive these badges, we have publicly released all the source code and data of Tailor.
Besides, we have documented step-to-step guidance to run experiments and reproduce results reported in our paper. 
We have also prepared a docker image to set up our experimental environment.